5 sources
---------- 
Fields:
----------
label: the name of the geographical point.
lat: latitude
lon: longitude
id: unique id of the entity
ontology: the source title. Sources are listed as "dbpedia, freebase, newyork times, geonames"
---------
lat and lon can be missing
---------
The file combinedSettlements(PerfectMatch).json contains the matched entites named as clusteredVertices